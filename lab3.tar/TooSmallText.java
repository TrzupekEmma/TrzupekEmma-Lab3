class TooSmallText extends Exception {
      public TooSmallText(String message){
         super(message);
      }
      public TooSmallText(){}
 }
