class InvalidStopwordException extends Exception {
      public InvalidStopwordException(String input){
         super(input);
      }
      public InvalidStopwordException(){}
 }
